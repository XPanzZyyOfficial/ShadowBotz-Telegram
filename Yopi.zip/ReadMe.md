CMD RUN BOT DI VPS
```
git clone https://github.com/pakiubot/ubotv1
```
```
pakiubot
```
```
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
```
```
sudo apt update && sudo apt upgrade -y
```
```
sudo apt install python3.10-venv ffmpeg -y
```
```
cd ubotv1
```
```
screen -S ubotv1
```
```
python3 -m venv didin - (awal deploy aja)
```
```
source didin/bin/activate
```
```
pip install --no-cache-dir -r requirements.txt
```
```
cp sample.env .env
```
```
nano .env (isi varsnya, ctrl + s buat save, ctrl + x buat exit nano)
```
```
bash start
